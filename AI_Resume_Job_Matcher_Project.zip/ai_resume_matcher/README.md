# AI-Powered Resume & Job Description Matcher

A beginner-friendly Python project that compares a resume with a job description and creates a simple match report.

## Features
- Upload a resume as PDF or TXT, or paste resume text.
- Paste a job description.
- Calculate text similarity using **TF-IDF** and **cosine similarity**.
- Detect skills from both texts using a simple keyword list.
- Show matching skills and skills mentioned in the job description but not found in the resume.

## Tech stack
- Python
- Streamlit
- scikit-learn
- PyPDF

## Run locally

1. Install Python 3.10 or later.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. (Recommended) Create and activate a virtual environment:

   ```bash
   python -m venv .venv
   ```

   Windows:

   ```bash
   .venv\Scripts\activate
   ```

   macOS/Linux:

   ```bash
   source .venv/bin/activate
   ```

5. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

6. Start the app:

   ```bash
   streamlit run app.py
   ```

7. Open the local URL shown in the terminal (usually http://localhost:8501).

## How it works
1. Text is extracted from the uploaded resume (PDF or TXT).
2. TF-IDF converts the resume and job description into numerical text vectors.
3. Cosine similarity estimates how similar the two texts are.
4. A small keyword-based skill matcher lists shared and missing skills.

## Limitations
- The similarity score is not a probability of getting hired.
- Skill detection uses a predefined keyword list and may miss synonyms or skills written in unusual formats.
- Scanned/image-only PDFs may not contain extractable text; paste the resume text in that case.
- The app does not send resume data to an external AI service.

## Possible improvements
- Add more skills and synonym handling.
- Add unit tests.
- Save reports as downloadable PDF files.
- Add semantic embeddings for deeper meaning-based matching.

## Interview explanation
"I built a Resume and Job Description Matcher using Python. It extracts text from PDF or TXT resumes, uses TF-IDF to represent the text numerically, and calculates cosine similarity to estimate how closely the resume matches a job description. I also added skill extraction to show matching and missing skills. I used Streamlit to build the user interface."

## Disclaimer
This is an educational project and should be used as a guidance tool, not as an automated recruitment or rejection system.
