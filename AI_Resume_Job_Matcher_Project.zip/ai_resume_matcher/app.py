import re
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from pypdf import PdfReader

st.set_page_config(page_title="AI Resume Matcher", page_icon="🧠", layout="wide")

SKILLS = [
    "python", "java", "c", "c++", "sql", "mysql", "mongodb", "html", "css",
    "javascript", "react", "node.js", "flask", "django", "machine learning",
    "deep learning", "artificial intelligence", "data analysis", "pandas",
    "numpy", "scikit-learn", "tensorflow", "pytorch", "nlp", "git", "github",
    "aws", "azure", "docker", "linux", "excel", "power bi", "communication",
    "problem solving", "data structures", "oop", "rest api"
]

def read_resume(uploaded_file):
    """Read text from an uploaded TXT or PDF resume."""
    if uploaded_file is None:
        return ""
    if uploaded_file.name.lower().endswith(".pdf"):
        reader = PdfReader(uploaded_file)
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    return uploaded_file.getvalue().decode("utf-8", errors="ignore")

def extract_skills(text):
    """Find known skills mentioned in the supplied text."""
    normalized = text.lower()
    found = []
    for skill in SKILLS:
        pattern = r"(?<![a-z0-9+#.])" + re.escape(skill) + r"(?![a-z0-9+#.])"
        if re.search(pattern, normalized):
            found.append(skill)
    return sorted(set(found))

def calculate_similarity(resume_text, job_text):
    """Calculate TF-IDF cosine similarity between resume and job description."""
    vectorizer = TfidfVectorizer(stop_words="english")
    matrix = vectorizer.fit_transform([resume_text, job_text])
    return float(cosine_similarity(matrix[0:1], matrix[1:2])[0][0] * 100)

st.title("🧠 AI-Powered Resume & Job Description Matcher")
st.write(
    "Compare a resume with a job description using TF-IDF and cosine similarity. "
    "The app also highlights skills found in each text."
)
st.info("This is a learning/demo tool. Its match score is a text-similarity estimate, not a hiring decision.")

left, right = st.columns(2)
with left:
    st.subheader("1. Add your resume")
    uploaded = st.file_uploader("Upload a resume (PDF or TXT)", type=["pdf", "txt"])
    resume_text = st.text_area("Or paste resume text here", height=260,
                               placeholder="Paste your resume content...")
    if uploaded is not None:
        extracted = read_resume(uploaded)
        if extracted.strip():
            resume_text = extracted
            st.success(f"Read text from {uploaded.name}")
        else:
            st.warning("No selectable text found. Try pasting the resume text instead.")

with right:
    st.subheader("2. Add the job description")
    job_text = st.text_area("Paste the job description", height=340,
                            placeholder="Paste the role requirements and responsibilities...")

if st.button("Analyze match", type="primary", use_container_width=True):
    if not resume_text.strip() or not job_text.strip():
        st.error("Please provide both resume text and a job description.")
    else:
        score = calculate_similarity(resume_text, job_text)
        resume_skills = set(extract_skills(resume_text))
        job_skills = set(extract_skills(job_text))
        matched = sorted(resume_skills & job_skills)
        missing = sorted(job_skills - resume_skills)

        st.divider()
        st.subheader("3. Match report")
        metric_col, skill_col = st.columns([1, 2])
        with metric_col:
            st.metric("Text similarity", f"{score:.1f}%")
            st.progress(min(score / 100, 1.0))
        with skill_col:
            st.write(f"**Skills detected in resume:** {len(resume_skills)}")
            st.write(f"**Skills detected in job description:** {len(job_skills)}")
            st.write(f"**Matching skills:** {len(matched)}")

        c1, c2 = st.columns(2)
        with c1:
            st.markdown("#### ✅ Matching skills")
            st.write(", ".join(matched) if matched else "No matching skills detected.")
        with c2:
            st.markdown("#### 📌 Skills to consider learning")
            st.write(", ".join(missing) if missing else "No additional listed skills detected.")

        st.markdown("#### Suggestions")
        if missing:
            st.write("Review the missing skills and learn the ones that genuinely match your experience and interests.")
        else:
            st.write("The listed skills overlap. Review the job requirements carefully and tailor your project descriptions.")
        st.caption("Tip: Add measurable achievements and truthful project details to your resume. Never add skills you do not have.")
